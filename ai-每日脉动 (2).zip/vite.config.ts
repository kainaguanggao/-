import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  define: {
    // 这行代码确保 Vercel 的环境变量能被代码识别
    'process.env.API_KEY': JSON.stringify(process.env.API_KEY)
  }
});