
import { GoogleGenAI } from "@google/genai";
import { DailyReport } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const extractJson = (text: string) => {
  try {
    return JSON.parse(text);
  } catch (e) {
    const match = text.match(/\{[\s\S]*\}/);
    if (match) {
      try {
        return JSON.parse(match[0]);
      } catch (innerE) {
        throw new Error("模型生成的 JSON 格式不正确，请刷新重试。");
      }
    }
    throw new Error("无法从 AI 响应中提取结构化数据。");
  }
};

export const fetchLatestAITrends = async (): Promise<DailyReport> => {
  const today = new Date().toLocaleDateString('zh-CN');
  
  const prompt = `
    你是一名世界级的 AI 商业分析师和产品专家。请利用 Google 搜索能力，深度调研并整理今天（${today}）的全球 AI 动态。
    
    你必须按照以下四个板块提供深度内容，【重要限制：每个板块必须包含 3 到 5 个条目】：

    1. 【全球 AI 大事件】：搜集今日最重磅的行业动态（如大模型更新、巨头竞争、重大融资、技术突破）。
    2. 【热门新工具雷达】：挖掘今日新发布或重大更新的工具。必须涵盖：语言(LLM)、图像设计、视频生成、音频音乐。
    3. 【前沿玩法指南】：【核心板块】搜集 3-5 个今日最火的 AI 创意玩法。每个玩法必须包含：玩法名称、核心逻辑描述、1个具体的社交媒体实操案例、4个详细步骤。
    4. 【商业成功案例】：【核心板块】搜集 3-5 个 AI 在具体行业（如跨境电商、私域运营、工业制造、内容创业）的落地赚钱案例。分析其变现逻辑、具体的 ROI 或盈利数据、以及针对普通人的商业避坑建议。

    请严格按照以下 JSON 格式输出，不要包含额外解释，直接输出 JSON 块。确保每个数组字段都有 3-5 个对象：
    {
      "date": "${today}",
      "headline": "今日 AI 全球决策参考",
      "summary": "一句话总结今日最核心的 AI 趋势",
      "events": [{"title": "事件名称", "summary": "描述", "impact": "解析"}],
      "tools": [{"name": "名称", "category": "分类", "description": "简介", "url": "网址", "highlight": "杀手锏"}],
      "playstyles": [{"title": "玩法名", "description": "逻辑", "communityCase": "他人成功案例描述", "tutorialSteps": ["步骤1", "步骤2", "步骤3", "步骤4"]}],
      "businessCases": [{"title": "方案名", "industry": "行业", "solution": "落地细节", "result": "赚钱数据/效果", "monetizationTip": "避坑建议"}]
    }
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        thinkingConfig: { thinkingBudget: 32768 }
      },
    });

    const textOutput = response.text || "";
    const result = extractJson(textOutput);
    
    const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.map((chunk: any) => ({
      title: chunk.web?.title || "权威参考",
      uri: chunk.web?.uri || "#"
    })) || [];

    return {
      ...result,
      lastUpdated: new Date().toISOString(),
      sources
    };
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw new Error(error instanceof Error ? `同步失败: ${error.message}` : "数据流同步失败");
  }
};
